import {
  ArrowUpRight,
  Building2,
  ClipboardCheck,
  Landmark,
  Route,
} from "lucide-react";

import { appConfig } from "@/lib/constants/navigation";
import { cn } from "@/lib/utils";

const highlights = [
  {
    icon: Route,
    title: "End-to-End Workflow",
    description:
      "From diary registration and Collector assignment to compliance review and verified closure.",
    tag: "Full lifecycle",
    colors: {
      card: "hover:border-emerald-200/80",
      icon: "bg-emerald-100 text-emerald-600 ring-emerald-200/80",
      title: "text-emerald-700",
      tag: "bg-emerald-100 text-emerald-700",
      arrow: "group-hover:text-emerald-600",
    },
  },
  {
    icon: Building2,
    title: "Multi-Department Routing",
    description:
      "Assign DAK to departments and sections with clear ownership and progress tracking.",
    tag: "Collectorate",
    colors: {
      card: "hover:border-sky-200/80",
      icon: "bg-sky-100 text-sky-600 ring-sky-200/80",
      title: "text-sky-700",
      tag: "bg-sky-100 text-sky-700",
      arrow: "group-hover:text-sky-600",
    },
  },
  {
    icon: ClipboardCheck,
    title: "Compliance & Closure",
    description:
      "Departments submit action taken and ATR; Collector approves or returns for rework.",
    tag: "ATR review",
    colors: {
      card: "hover:border-amber-200/80",
      icon: "bg-amber-100 text-amber-700 ring-amber-200/80",
      title: "text-amber-800",
      tag: "bg-amber-100 text-amber-800",
      arrow: "group-hover:text-amber-700",
    },
  },
] as const;

export function AuthBrandPanel() {
  return (
    <div className="relative w-full overflow-hidden rounded-2xl border border-primary/15 bg-card/90 p-5 shadow-lg backdrop-blur-sm sm:p-6 lg:p-7">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary via-[oklch(0.45_0.12_255)] to-primary/60" />
      <div className="auth-visual-orb auth-visual-orb-a pointer-events-none absolute -top-8 -right-8 size-32 rounded-full bg-primary/10 blur-2xl" />

      <div className="relative z-10 flex min-w-0 items-center gap-3">
        <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-md shadow-primary/20 ring-1 ring-primary/20">
          <Landmark className="size-7" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-base font-bold text-foreground">
            {appConfig.name}
          </p>
          <p className="truncate text-sm text-muted-foreground">
            {appConfig.shortName} · DOIT&C Rajasthan
          </p>
        </div>
      </div>

      <div className="relative z-10 mt-5 space-y-5">
        <div className="space-y-2">
          <p className="text-xs font-semibold tracking-[0.12em] text-primary uppercase">
            Government of Rajasthan · District Portal
          </p>
          <h1 className="text-xl leading-tight font-bold tracking-tight text-foreground sm:text-2xl xl:text-[1.65rem]">
            {appConfig.fullName}
          </h1>
          <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
            Official Khairthal-Tijara district portal for correspondence
            monitoring, departmental compliance, Collector review, and
            administrative oversight under Rajasthan e-Governance standards.
          </p>
        </div>

        <ul className="grid gap-2.5 lg:grid-cols-3">
          {highlights.map(({ icon: Icon, title, description, tag, colors }) => (
            <li
              key={title}
              className={cn(
                "group relative overflow-hidden rounded-xl border border-border/60 bg-background/70 p-3.5 shadow-sm transition-all duration-200 hover:shadow-md",
                colors.card
              )}
            >
              <div className="flex items-start gap-3">
                <div
                  className={cn(
                    "flex size-9 shrink-0 items-center justify-center rounded-lg ring-1",
                    colors.icon
                  )}
                >
                  <Icon className="size-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className={cn("text-sm font-semibold", colors.title)}>
                      {title}
                    </p>
                    <span
                      className={cn(
                        "rounded-md px-2 py-0.5 text-[10px] font-medium tracking-wide uppercase",
                        colors.tag
                      )}
                    >
                      {tag}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                    {description}
                  </p>
                </div>
                <ArrowUpRight
                  className={cn(
                    "mt-0.5 size-4 shrink-0 text-muted-foreground/50 transition-all group-hover:translate-x-0.5 group-hover:-translate-y-0.5",
                    colors.arrow
                  )}
                />
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
