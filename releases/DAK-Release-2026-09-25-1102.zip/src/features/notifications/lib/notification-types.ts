/** Notification categories — maps to notifications.type in Postgres. */
export type NotificationType =
  | "dak_created"
  | "dak_assigned"
  | "dak_reassigned"
  | "dak_completed"
  | "status_updated"
  | "dak_overdue"
  | "sla_due_tomorrow"
  | "dak_escalated"
  | "user_created"
  | "password_reset"
  | "user_disabled"
  | "user_enabled"
  | "remark_added"
  | "atr_submitted"
  | "transfer_requested"
  | "transfer_approved"
  | "transfer_rejected"
  | "escalation_requested"
  | "escalation_resolved"
  | "extension_requested"
  | "extension_approved"
  | "extension_rejected"
  | "closure_approved"
  | "returned_for_rework"
  | "compliance_resubmitted"
  | "clarification_requested"
  | "clarification_replied"
  | "task_assigned"
  | "task_assignee_completed"
  | "task_consolidation_required"
  | "task_closed";

export const NOTIFICATION_TYPE_LABELS: Record<NotificationType, string> = {
  dak_created: "New DAK Registered",
  dak_assigned: "DAK Assigned",
  dak_reassigned: "DAK Reassigned",
  dak_completed: "DAK Completed",
  status_updated: "Status Updated",
  dak_overdue: "Overdue DAK",
  sla_due_tomorrow: "SLA Due Tomorrow",
  dak_escalated: "DAK Escalated",
  user_created: "User Created",
  password_reset: "Password Reset",
  user_disabled: "User Disabled",
  user_enabled: "User Enabled",
  remark_added: "Remark Added",
  atr_submitted: "ATR Submitted",
  transfer_requested: "Transfer Requested",
  transfer_approved: "Transfer Approved",
  transfer_rejected: "Transfer Rejected",
  escalation_requested: "Escalation Requested",
  escalation_resolved: "Escalation Resolved",
  extension_requested: "Extension Requested",
  extension_approved: "Extension Approved",
  extension_rejected: "Extension Rejected",
  closure_approved: "Closure Approved",
  returned_for_rework: "Returned for Rework",
  compliance_resubmitted: "Revised Compliance Submitted",
  clarification_requested: "Clarification Requested",
  clarification_replied: "Clarification Reply Received",
  task_assigned: "Task Assigned",
  task_assignee_completed: "Task Submission Received",
  task_consolidation_required: "Consolidated Report Required",
  task_closed: "Task Closed",
};

/** Supabase Realtime channel name — subscribe per user in future. */
export const NOTIFICATIONS_REALTIME_CHANNEL = "notifications";
