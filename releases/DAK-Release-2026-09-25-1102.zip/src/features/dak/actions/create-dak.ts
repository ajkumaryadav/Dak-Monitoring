"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import {
  createDakSchema,
  type CreateDakInput,
} from "@/features/dak/schemas/dak-schema";
import { syncUserProfile } from "@/features/auth/actions/sync-user";
import { uploadDakAttachment } from "@/features/dak/actions/upload-attachment";
import { validateAttachmentFile } from "@/features/dak/lib/attachment-validation";
import { getDistrictDateString } from "@/features/dak/lib/dak-dates";
import { logWorkflowAction } from "@/features/dak/services/log-workflow";
import { createActivityLog } from "@/features/activity/services/activity-log";
import { notifyDakCreated } from "@/features/notifications/services/notify-dak-event";
import { hasPermission, isOperatorDashboardRole, PERMISSIONS } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { getSessionUser } from "@/lib/session";
import { logSafeError, formatSafeErrorMessage } from "@/lib/security/errors";

export type CreateDakResult =
  | { success: true; dakId: string }
  | { success: false; message: string };

export type CreateDakFormState = {
  message?: string;
  errors?: Partial<Record<keyof CreateDakInput, string[]>>;
};

function getAttachmentFromFormData(
  formData: FormData
): File | undefined {
  const entry = formData.get("attachment");

  if (!(entry instanceof File) || entry.size === 0) {
    return undefined;
  }

  return entry;
}

/** Register a new DAK entry in Supabase. */
export async function createDak(
  input: CreateDakInput,
  attachment?: File
): Promise<CreateDakResult> {
  try {
    const user = await getSessionUser();

    if (!user) {
      return {
        success: false,
        message: "Your session has expired. Please sign in again.",
      };
    }

    if (!hasPermission(user.role, PERMISSIONS.DAK_ENTRY)) {
      return {
        success: false,
        message: "You do not have permission to register DAK entries.",
      };
    }

    if (attachment) {
      const fileValidation = validateAttachmentFile(attachment);

      if (!fileValidation.valid) {
        return { success: false, message: fileValidation.message };
      }
    }

    await syncUserProfile();

    const parsed = createDakSchema.safeParse(input);

    if (!parsed.success) {
      return {
        success: false,
        message: parsed.error.issues[0]?.message ?? "Invalid form data",
      };
    }

    const supabase = createAdminClient();
    const receivedDate = getDistrictDateString();
    const departmentId = isOperatorDashboardRole(user.role)
      ? null
      : parsed.data.departmentId ?? null;

    const { data: inserted, error } = await supabase
      .from("dak_entries")
      .insert({
        dak_number: `DAK-${Date.now()}`,
        subject: parsed.data.subject,
        sender: parsed.data.senderName,
        sender_address: parsed.data.senderAddress,
        applicant_mobile: parsed.data.applicantMobile,
        applicant_reference: parsed.data.applicantReference ?? null,
        priority: "routine",
        department_id: departmentId,
        source_id: parsed.data.sourceId,
        due_date: null,
        sla_due_date: null,
        escalation_level: 0,
        description: parsed.data.remarks?.trim() || null,
        status: "received",
        received_date: receivedDate,
        created_by: user.id,
      })
      .select("id, dak_number")
      .single();

    if (error || !inserted) {
      logSafeError("createDak:db", error);
      return {
        success: false,
        message: formatSafeErrorMessage(error, "Failed to save DAK entry."),
      };
    }

    await logWorkflowAction({
      dakId: inserted.id,
      userId: user.id,
      eventType: "dak_registered",
      timelineActionType: "dak_created",
      action: "DAK Registered",
      remarks: parsed.data.remarks?.trim() || "Registered by data entry operator",
    });

    await createActivityLog({
      userId: user.id,
      action: "DAK Create",
      module: "dak",
      description: `Registered ${inserted.dak_number}: ${parsed.data.subject}`,
      metadata: { dak_id: inserted.id, dak_number: inserted.dak_number },
    });

    await notifyDakCreated({
      dakId: inserted.id as string,
      dakNumber: inserted.dak_number as string,
      subject: parsed.data.subject,
      actorUserId: user.id,
      actorName: user.name,
    });

    if (attachment) {
      const uploadResult = await uploadDakAttachment(
        inserted.id,
        attachment,
        user.id
      );

      if (!uploadResult.success) {
        return {
          success: false,
          message: `DAK saved but attachment upload failed: ${uploadResult.message}`,
        };
      }

      await logWorkflowAction({
        dakId: inserted.id,
        userId: user.id,
        eventType: "remarks_added",
        timelineActionType: "file_uploaded",
        action: "Attachment uploaded",
        remarks: attachment.name,
      });
    }

    return { success: true, dakId: inserted.id };
  } catch (error: unknown) {
    logSafeError("createDak", error);
    return {
      success: false,
      message: formatSafeErrorMessage(error, "An unexpected error occurred while saving."),
    };
  }
}

/** Form action for DAK registration — same pattern as login. */
export async function createDakFormAction(
  _prevState: CreateDakFormState,
  formData: FormData
): Promise<CreateDakFormState> {
  const attachment = getAttachmentFromFormData(formData);

  if (attachment) {
    const fileValidation = validateAttachmentFile(attachment);

    if (!fileValidation.valid) {
      return {
        message: fileValidation.message,
        errors: { attachment: [fileValidation.message] },
      };
    }
  }

  const parsed = createDakSchema.safeParse({
    subject: formData.get("subject"),
    senderName: formData.get("senderName"),
    senderAddress: formData.get("senderAddress"),
    applicantMobile: formData.get("applicantMobile"),
    applicantReference: formData.get("applicantReference") ?? "",
    departmentId: formData.get("departmentId") ?? "",
    sourceId: formData.get("sourceId"),
    remarks: formData.get("remarks") ?? "",
    attachment,
  });

  if (!parsed.success) {
    return {
      message: parsed.error.issues[0]?.message ?? "Invalid form data",
      errors: parsed.error.flatten().fieldErrors as CreateDakFormState["errors"],
    };
  }

  const result = await createDak(parsed.data, attachment);

  if (!result.success) {
    return { message: result.message };
  }

  revalidatePath("/dashboard/dak");
  revalidatePath("/dashboard/dak/pending");
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/audit");
  revalidatePath("/dashboard/notifications");
  revalidatePath(`/dashboard/dak/${result.dakId}`);
  redirect(`/dashboard/dak/${result.dakId}`);
}
